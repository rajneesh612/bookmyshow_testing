package bookMyShow;

import java.io.File;
import java.io.FileOutputStream;

import org.apache.commons.io.FileUtils;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.testng.ITestContext;
import org.testng.ITestListener;
import org.testng.ITestResult;

import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.Status;

import bookMyShow.Utillity.BaseClass;
import ru.yandex.qatools.ashot.Screenshot;

public class Listner extends BaseClass implements ITestListener  {
 WebDriver driver;
 ExtentTest extentTestReport;
 	public void onTestStart(ITestResult result) {
		System.out.println("test started " +result.getName());
	}
 	public void onTestSuccess(ITestResult result) {
		System.out.println("test passed " +result.getName());
		driver = webdriver;
		TakesScreenshot t = (TakesScreenshot)driver;
		//File srcFile = t.getScreenShotAs(Screenshot.FILE);  
		byte[] logo =t.getScreenshotAs(OutputType.BYTES);
		try(FileOutputStream save = new FileOutputStream(new File("D:\\java\\files\\images\\bookmyshow\\" +result.getName()+"."+"png"))){
			save.write(logo);
		}
		catch(Exception e) {
			e.printStackTrace();
		}

		
		
	}
 	public void onTestFailure(ITestResult result) {
		System.out.println("test failed " +result.getName());
		
		
		
		driver = webdriver;
		TakesScreenshot t = (TakesScreenshot)driver;
		//File srcFile = t.getScreenShotAs(Screenshot.FILE);  
		byte[] logo =t.getScreenshotAs(OutputType.BYTES);
		try(FileOutputStream save = new FileOutputStream(new File("D:\\java\\files\\images\\" +result.getName()+"."+"png"))){
			save.write(logo);
		}
		catch(Exception e) {
			e.printStackTrace();
		}

		
		  
	
	}
	@Override
	public void onTestSkipped(ITestResult result) {
		System.out.println(" test skipped " +result.getName());
	}


	/*
	 * public void onFinish(ITestResult result) {
	 * System.out.println(" test finnished " +result.getName());
	 * 
	 * 
	 * }
	 */
	
	@Override  
	public void onFinish(ITestContext context) {  
	// TODO Auto-generated method stub  
		System.out.println(" test finnished " +context.getClass());
		
		//driver.quit();
	} 
}