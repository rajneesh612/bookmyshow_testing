package bookMyShow;

import java.io.IOException;
import java.time.Duration;

import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import bookMyShow.AllTestPages.List_your_show_page;
import bookMyShow.AllTestPages.home_page;
import bookMyShow.All_Genric_Methods.Click_WebElements;
import bookMyShow.Utillity.BaseClass;

public class BookMyShowTest extends BaseClass{
	
	@BeforeTest 
	public void intialize_browser() throws IOException {
		webdriver.manage().timeouts().implicitlyWait(Duration.ofMillis(2000));
		//initializebrowser();
		webdriver.get(url);
	}
	
	
	  @Test(priority = 1) 
	  public void home_page_test() {
	  
	  Click_WebElements.btnClick(home_page.select_city());
	 // Click_WebElements.btnClick(home_page.sign_in());
	// home_page.enter_mobile_number().sendKeys(phone_number);
	 // Click_WebElements.btnClick(home_page.continue_login()); 
	  }
	 
	
	
	@Test(priority = 2) 
	public void list_your_show_link_test() {
		Click_WebElements.btnClick(List_your_show_page.list_Your_Show_link());
		//Click_WebElements.btnClick(List_your_show_page.list_your_show_button());
		
		//List_your_show_page.Enter_Details().get(2);
	}
	
	@Test(priority = 3) 
	public void form_fill_test() throws InterruptedException {
		//Click_WebElements.btnClick(List_your_show_page.list_Your_Show_link());
		Thread.sleep(10000);
		// ------------------clicking on the List your show button ----------------------//
		webdriver.manage().timeouts().implicitlyWait(Duration.ofMillis(5000));
		Click_WebElements.btnClick(List_your_show_page.list_your_show_button());
		// ---------Clicking on the list your show pop up -------------------------------//
		Click_WebElements.btnClick(List_your_show_page.list_your_show_popup());
		//-------------------entering the name in form ----------------------------------//
		List_your_show_page.enter_name().sendKeys("xyzABC");
		//-------------------entering the email id in the form --------------------------//
		List_your_show_page.enter_email_id().sendKeys("xyzABC@mailinator.com");
		//---------------------enter the phone number in the form -----------------------//
		List_your_show_page.enter_phone_number().sendKeys("9298150651");
		
		// ------------------selecting region-------------------//
		Click_WebElements.btnClick(List_your_show_page.region_select());
		//----------------select a city -------------------------------------------------//
		Click_WebElements.btnClick(List_your_show_page.city_select());
		//----------------selecting event type ------------------------------------------//
		Click_WebElements.btnClick(List_your_show_page.event_type_select());
		//----------------selecting expected audience -----------------------------------//
		Click_WebElements.btnClick(List_your_show_page.expected_audience_select());
		//----------------selecting date ------------------------------------------------//
		Click_WebElements.btnClick(List_your_show_page.date_select());
		// -------------enter the description -------------------------------------------//
		List_your_show_page.enter_discription().sendKeys("This is testing . This is testing .This is testing .This is testing ."
				+ "This is testing .This is testing .This is testing .This is testing .This is testing .This is testing .This is testing ");
		
		// -------------click on  the submit button ---------------------------------------------//		
		Click_WebElements.btnClick(List_your_show_page.submit_button());
		//----------------click on the share button----------------------------------------------//
		Thread.sleep(5000);
		Click_WebElements.btnClick(List_your_show_page.share_button());
		//----------------click on share on twitter----------------------------------------------//
		Click_WebElements.btnClick(List_your_show_page.share_on_twitter());
		
		//-----------------switch to child window -----------------------------------------------//
		List_your_show_page.switch_to_child_window();
		
		
		Thread.sleep(5000);
		//--------------------enter user id in twitter login ------------------------------------//
		List_your_show_page.user_id_twitter().sendKeys("rajneesh612");
		
		//-----------------------enter password in twitter login --------------------------------//
		List_your_show_page.passwd_twitter().sendKeys("54321cms@");
		
		//----------------------click on login button--------------------------------------------//
		Click_WebElements.btnClick(List_your_show_page.login_btn_twitter());
		
		// ---------------------tweet your form -------------------------------------------------//
		Thread.sleep(5000);
		Click_WebElements.btnClick(List_your_show_page.tweet_form());
		
	}
	
	

}
