package bookMyShow.All_Genric_Methods;

import java.time.Duration;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import bookMyShow.Utillity.BaseClass;

public class Click_WebElements extends BaseClass {
	public static  WebElement btnClick(WebElement e)  {
	    WebDriverWait wait2=new WebDriverWait(webdriver,Duration.ofSeconds(30));
	    
	    wait2.until(ExpectedConditions.elementToBeClickable(e)).click();
		return e;

}
}
