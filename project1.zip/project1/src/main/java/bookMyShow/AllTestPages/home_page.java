package bookMyShow.AllTestPages;

import org.apache.xmlbeans.impl.xb.xsdschema.Public;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;

import bookMyShow.Utillity.BaseClass;

public class home_page extends BaseClass {
	public static WebElement city_name;
	
	public static WebElement select_city() {
		
	city_name = webdriver.findElement(By.xpath("//img[@alt='NCR']"));
		return city_name;
		
	}
	
	public static WebElement sign_in () {
		WebElement sign_in_Element = webdriver.findElement(By.xpath("//div[text()='Sign in']"));
		return sign_in_Element;
	}
	
	public static WebElement enter_mobile_number() {
		
		WebElement mobile_number_field = webdriver.findElement(By.xpath("//input[@id='mobileNo']"));
		
		
		return mobile_number_field;
		
	}
	
	public static WebElement continue_login() {
		WebElement continue_WebElement = webdriver.findElement(By.xpath("//button[text()='Continue']"));
		return continue_WebElement;
	}
	
	public static WebElement otp_verification() {
		return null;
		
	}

}
