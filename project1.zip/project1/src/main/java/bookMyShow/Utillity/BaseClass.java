 package bookMyShow.Utillity;

	

	import java.io.FileInputStream;
	import java.io.IOException;
	import java.io.InputStream;
	import java.util.Properties;

	import org.openqa.selenium.WebDriver;
	import org.openqa.selenium.chrome.ChromeDriver;
	import org.openqa.selenium.chrome.ChromeOptions;
	import org.openqa.selenium.edge.EdgeDriver;
	import org.openqa.selenium.firefox.FirefoxDriver;
	import org.testng.annotations.BeforeTest;
	import org.testng.annotations.Test;



	public class BaseClass {
		protected static WebDriver webdriver;
		protected Properties config;
		protected String configFilename = "config";
		
		public String  browser_name;
		public String url;
		public String client_name;
		public String login_username;
		public String next_btn1;
		public String login_passwd;
		public String next_btn2;
		public String mail_icon;
		public String userid;
		public String passwd;
		public String subjectString;
		public String phone_number;
		
		
		public String heading_page1;
		public static Properties prop = new Properties();
		public static Properties prop_loc = new Properties();
		
		@BeforeTest
		protected WebDriver initializebrowser() throws IOException{
	
		//	C:\Users\Rajneesh Sharma\eclipse-workspace\project1\src\test\java\properties_bookmyshow_test
			try {
				FileInputStream fis= new FileInputStream( System.getProperty("user.dir")+"\\src\\test\\java\\properties_bookmyshow_test\\base.properties");
				//Properties prop = new Properties();
				prop.load(fis);
				url = prop.getProperty("url");     // reading data from property file "base.properties"
				browser_name = prop.getProperty("name");
				client_name = prop.getProperty("client_name");
				userid = prop.getProperty("userid");
				passwd = prop.getProperty("passwd");
				subjectString= prop.getProperty("subject");
				phone_number = prop.getProperty("client_phn_number");
				
				//heading_page1 = prop.getProperty("heading_page1");
				
				
				  //FileInputStream fis_loc = new FileInputStream(System.getProperty("user.dir")+ "\\src\\test\\java\\properties_sakara_testing\\locators_sakara_test.properties"); 
				  
				  //prop_loc.load(fis_loc); 
				 // heading_page1 = prop_loc.getProperty("heading_page1");
				 

			
			}
			catch (IOException ex) {
				ex.printStackTrace();
			}   
			
			if(browser_name.equalsIgnoreCase("Mozilla")) {
				//if(browser_name.equals("Mozilla")) {	
				System.setProperty("webdriver.gecko.driver","D:\\java\\selenium-web-driver\\geckodriver-v0.30.0-win64\\geckodriver.exe");
				webdriver = new FirefoxDriver();
				webdriver.manage().window().maximize();
			}
			else if(browser_name.equalsIgnoreCase("chrome")) {
				//else if(browser_name.equals("chrome")) {
				System.setProperty("webdriver.chrome.driver","D:\\java\\selenium-web-driver\\chrome-driver\\chromedriver_win32\\chromedriver.exe");
				ChromeOptions options = new ChromeOptions();
				options.addArguments("--disable-extensions");
				options.addArguments("--start-maximized");
				webdriver = new ChromeDriver(options);
			}
			else if(browser_name.equalsIgnoreCase("edge")) {
				//else if(browser_name.equals("edge")) {
				System.setProperty("webdriver.edge.driver","D:\\java\\selenium-web-driver\\edge-driver\\edgedriver_win64\\msedgedriver.exe");
				webdriver=new EdgeDriver();
				webdriver.manage().window().maximize();
			}
			return webdriver;
			
	}		}


